StartupEvents.registry('sound_event', event => {
    event.create('omni_extras:eyebeam');
    event.create('omni_extras:openeye');
    event.create('omni_extras:stalk');
    event.create('omni_extras:otherbeam');
    event.create('omni_extras:swallow');
    event.create('omni_extras:blast');
    event.create('omni_extras:chomp');
    event.create('omni_extras:whip');
    event.create('omni_extras:gangsta');
    event.create('omni_extras:grumble');
    event.create('omni_extras:release');
    event.create("omni_extras:sonic_laugh");
    event.create("omni_extras:laugh");
})