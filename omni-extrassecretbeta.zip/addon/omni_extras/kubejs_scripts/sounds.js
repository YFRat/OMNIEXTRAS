StartupEvents.registry('sound_event', event => {
    event.create('alienevo:eyebeam')
    event.create('alienevo:openeye')
    event.create('alienevo:stalk')
    event.create('alienevo:otherbeam')
})