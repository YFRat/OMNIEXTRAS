StartupEvents.registry('sound_event', event => {
    event.create('upchuck:swallow')

})