StartupEvents.registry('sound_event', event => {
    event.create('upchuck:swallow')
    event.create('upchuck:blast')

})