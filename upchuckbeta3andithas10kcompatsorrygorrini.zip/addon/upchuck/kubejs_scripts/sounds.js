StartupEvents.registry('sound_event', event => {
    event.create('upchuck:swallow')
    event.create('upchuck:blast')
    event.create('upchuck:chomp')
    event.create('upchuck:whip')
    event.create('upchuck:gangsta')

})